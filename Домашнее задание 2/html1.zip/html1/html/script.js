    // alert(2+2);
    // const name = `Irina`;
    // alert(`Hello, ${name}`);

// let user_name = prompt("Как вас зовут?", "Имя");
// alert (`Привет, ${user_name}`);

function show_text(user_name){
    alert (`Привет, ${user_name}`);
}
let user_name = prompt("Как вас зовут?", "Имя");
show_text(user_name);
